function yukle() {
	/* Fonks */
	function yorumKutuAc() {
		//Aktif Et
		document.querySelector("li#tab-yorumlar").classList.add("active");

		//Diger Tablari Deaktif Et
		digerTablar.forEach(item => {
			var digerTab = document.querySelector("li."+ item);
			digerTab.classList.remove("active");
		})

		//Diger Tabların içeriğini gizle
		digerKutular.forEach(item => {
			var digerKutu = document.querySelector("div"+ item);
			digerKutu.style.display = "none";
		})

		//Yorum Kutusunu Göster
		document.querySelector("div#yorumkutu").style.display = "block";
	}

	/*Diğer Tab İşlemleri */
	var digerTablar = []
	document.querySelectorAll('div#classified-tabs ul li').forEach(item => {
		digerTablar.push(item.classList[0]);
	})

	/* Dğer Kutu İşlemleri */

	var digerKutular = []
	document.querySelectorAll('div#classified-tabs ul li a').forEach(item => {
		digerKutular.push(item.href.replace(location.href,""));
	})

	/*Yorum Sekmesi Ekle*/
	var ul = document.querySelector("div#classified-tabs ul")
	var li = document.createElement("li");
	var a = document.createElement("a");
	var linkyazi = document.createTextNode("İlan Yorumları");

	li.id="tab-yorumlar";
	//a.href="#yorumkutu";
	//a.id="yorumTab";
	a.appendChild(linkyazi);
	li.appendChild(a);
	ul.appendChild(li);
	li.addEventListener("click", yorumKutuAc);

	var globalYorumTabi = document.querySelector("li#tab-yorumlar");

	/* Diger Tablara Click Event Ekle */
	digerTablar.forEach(item => {
		var digerTab = document.querySelector("li."+ item);
		digerTab.addEventListener('click', event => {
			//YorumTab Deaktif Et
			console.log("Diger Tab Tiklandi => " + item)
			globalYorumTabi.classList.remove("active");

			//Yorum Kutusunu Gizle
			document.querySelector("div#yorumkutu").style.display = "none";
		  })
	})


	/* Yorum İçeriği Ekle*/
	var altKisim = document.querySelector("div.classifiedOtherDetails"); 

	var yorumBox = document.createElement("div");
	yorumBox.classList.add("mini-tab-content");
	yorumBox.id="yorumkutu";
	yorumBox.style.display = "none";

	var yorumBoxUi = document.createElement("div");
	yorumBoxUi.classList.add("uiBox");
	yorumBoxUi.innerHTML = `
	<div class="uiBoxTitle">
        <h3 class="uiDetailTitle">
            <a href="#classifiedYorum">Yorumlar</a>
        </h3>
    </div>
    <div id="classifiedYorum" class="uiBoxContainer">
    <p id="yorumduyuru"></p>
    <div id="disqus_thread"></div>
	<noscript>Yorumları görebilmek için Javascript'i aktifleştirin</noscript>
	</div>
	`;
	yorumBox.appendChild(yorumBoxUi);

	altKisim.appendChild(yorumBox);

	/* Duyuru Yazılsın */
	duyuruUrl = "https://raw.githubusercontent.com/muratcesmecioglu/sahibinden-yorum/master/duyuru.txt";
    if (window.XMLHttpRequest)
    { xmlhttp=new XMLHttpRequest(); }
    else
    { xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.querySelector("p#yorumduyuru").innerHTML = xmlhttp.responseText;
        }
    }
    xmlhttp.open("GET", duyuruUrl, false);
    xmlhttp.send();    


	/* Disqus Yükle */ 

	var disqus_config = function () {
	this.page.url = location.href;
	this.page.identifier = document.querySelector("input#classifiedIdValue").value;
	};
	(function() {
	var d = document, s = d.createElement('script');
	s.src = 'https://sahibindenyorum.disqus.com/embed.js';
	s.setAttribute('data-timestamp', +new Date());
	(d.head || d.body).appendChild(s);
	})();

}
yukle();
console.log("Sahibinden Yorum v1 - Loaded")